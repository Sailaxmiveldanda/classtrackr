// re usable functions will be written here
