// for static data present in the application
